﻿$('.add').click(function() {
    $("form")[0].reset();
});